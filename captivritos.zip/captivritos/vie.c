#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "vie.h"

void initialiservie(vie *vie)
{

vie->position.x =880 ;
vie->position.y = -10 ;
vie->fond1 = IMG_Load("vie/5.png");
vie->fond2 = IMG_Load("vie/4.png");
vie->fond3 = IMG_Load("vie/3.png");
vie->fond3 = IMG_Load("vie/2.png");
vie->fond3 = IMG_Load("vie/1.png");
vie->fond3 = IMG_Load("vie/6.jpg");

}

void affichervie(vie *vie,SDL_Surface *ecran , int *i )
{
SDL_BlitSurface(vie->fond1,NULL, ecran,&vie->position);

}





