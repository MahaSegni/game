#ifndef FCT_H_
#define FCT_H_
void menu();
#endif /* FCT_H_ */
