#ifndef SCROLLING_H_INCLUDED
#define SCROLLING_H_INCLUDED

#include<stdio.h>
#include<stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include"struct.h"
	/*extern background bckg;
	extern hero evan;

	extern void scrolling (hero *evan,background *bckg);*/


#endif
