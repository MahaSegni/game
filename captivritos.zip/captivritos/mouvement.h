#ifndef MOUVEMENT_H_INCLUDED
#define MOUVEMENT_H_INCLUDED
#include<stdio.h>
#include<stdlib.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_ttf.h>
#include"struct.h"
	/*hero evan ;
	extern void mouvment(hero *evan);*/
#endif