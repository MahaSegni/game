#include<stdio.h>
#include<stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include"struct.h"
void initialiser_objet(objet *chouka) {
	chouka->afficher_objet=NULL;
	chouka->afficher_objet=IMG_Load("s1.png");

	chouka->pos_objet.x=350;
	chouka->pos_objet.y=0;
}



void afficher_objet(objet *chouka,SDL_Surface *ecran,hero evan){

	if (chouka->pos_objet.x==0){
			srand(time(NULL)); 
		chouka->pos_objet.x=(rand()%900+300);  
		chouka->pos_objet.y=0;
	}
	if ((chouka->pos_objet.y<600)&&(evan.pos_hero2.x<=300)){
		if (evan.mouvment==1){
			chouka->pos_objet.x=chouka->pos_objet.x-5;
				chouka->pos_objet.y++;
				chouka->pos_objet.y++;
				chouka->pos_objet.y++;
				chouka->pos_objet.y++;
				}
			chouka->pos_objet.y++;
			if (evan.mouvment==2){
				chouka->pos_objet.x=chouka->pos_objet.x+5;
				chouka->pos_objet.y++;
				chouka->pos_objet.y++;
				chouka->pos_objet.y++;
				chouka->pos_objet.y++;
			}

			if (evan.mouvment==3){
				//chouka->pos_objet.x=chouka->pos_objet.x+50;
				chouka->pos_objet.y++;
				chouka->pos_objet.y++;
				chouka->pos_objet.y++;
				chouka->pos_objet.y++;
			}
	}

	else {
			srand(time(NULL)); 
		chouka->pos_objet.x=(rand()%900+300);  
		chouka->pos_objet.y=0;
	}
	if(evan.pos_hero2.x==300)
		SDL_BlitSurface(chouka->afficher_objet,NULL,ecran,&(chouka->pos_objet));
	else if (evan.pos_hero2.x>300)
		 chouka->afficher_objet=NULL;
}