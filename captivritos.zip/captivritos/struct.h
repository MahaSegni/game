
#ifndef STRUCT_H_INCLUDED
#define STRUCT_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <time.h>
 #include <unistd.h>


typedef struct Enemy
{
  SDL_Surface *image[3];
  SDL_Surface *image2[3];
  SDL_Surface *Hit;
  SDL_Surface *imageActuel;
  SDL_Rect position;
  SDL_Rect positionO;
  int frame;
  int direction;

}Enemy;

typedef struct hero
{
	int mouvment;
	SDL_Rect pos_hero[9];
	SDL_Surface *afficher_hero[9];
	SDL_Rect pos_hero2;
	int farm;
	int vie;
	SDL_Surface *afficher_vie;
	int score;
	SDL_Surface *afficher_score;
	SDL_Rect pos_vie;
	
}hero;

typedef struct objet{

	SDL_Surface *afficher_objet;
	SDL_Rect pos_objet;
}objet;
typedef struct background{

	SDL_Surface *afficher_background;
	SDL_Rect pos_background;
	SDL_Rect pos_background2;
	SDL_Surface *calque_background;
}background;



typedef struct menu{
	SDL_Surface *background;
	SDL_Surface *bplay;
	SDL_Surface *beplay;
	SDL_Surface *droit;	
	SDL_Surface *droite;
	SDL_Surface *gauche;
	SDL_Surface *gauchee;
	SDL_Surface *msetting;	
	SDL_Surface *besetting;
	SDL_Surface *bsetting;
	SDL_Surface *bquit;
	SDL_Surface *bequit;
	SDL_Rect positionecran;
	SDL_Rect positionbplay;
	SDL_Rect positiondroit;
	SDL_Rect positiongauche;
	SDL_Surface *sousmenuquit;
	SDL_Rect positionsousmenuquit;
	int action;
	int boutoneffet;
	int po;
	Mix_Music *son;	
	
} menu;

	int controle_menu ();
	void initialiser_menu(menu *menu);
	int affcihier(menu *menu,SDL_Surface *ecran);
	void affichier_quit(menu *menu,SDL_Surface *ecran,int x,int y);

	void initialiser_background(background *bckg);
void initialiser_backgroun(background *mini);
 	void afficher_background(background bckg,SDL_Surface *ecran);
	void initialiser_evan(hero *evan);
	void afficher_evan(hero evan,SDL_Surface *ecran);
	
	void scrolling (hero *evan,background *bckg);
	int animation_perso(hero evan);
	int mouvment(hero evan,SDL_Event *event);
	void initialiser_objet(objet *chouka);
	void afficher_objet(objet *chouka,SDL_Surface *ecran, hero evan);

	int Collision_Bounding_Box (hero evan ,objet chouka );


	Enemy InitEnemy(Enemy Ennemie,int x, int y);
	void  AfficherEnemy(Enemy Ennemie,SDL_Surface *screen);
	Enemy AnimateEnemy(Enemy Ennemie,int stat);
	Enemy MoveEnemy(Enemy Ennemie,SDL_Rect personnage,int *stat,int mouvment);

	int collision_Parfaite(SDL_Surface *calque,SDL_Surface *perso,SDL_Rect posperso,SDL_Rect posmap);

#endif
